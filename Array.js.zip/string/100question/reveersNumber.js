const arrayOfObjects = 12345
  
  
  function stortObj (a){
      let  rev =0 
      
      while (a>0){
           rev = rev*10+(a%10)
          a = Math.floor(a/10)
      
          
      }
      return rev
      
  }
  
  console.log(stortObj(arrayOfObjects))