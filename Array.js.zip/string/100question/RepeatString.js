
let str = "abbfghhvvav"

function RepatedStr (a){
    let rep =[]
    let seen =[]
   
    
    for(let i=0; i<=a.length-1; i++){
        let matchValue = false
           for(let j=0; j<=rep.length-1; j++){
               if(rep[j]===a[i]){
                   matchValue = true
                   let alredayseen = false 
                   
                   
                   for(let k=0; k<=seen.length-1;k++){
                       if(seen[k]=== a[i]){
                           alredayseen = true
                           break;
                       }
                   }
                   if(!alredayseen){
                        seen[seen.length]= a[i]
                   }
                  
                   
                   
               }
               
           }
           if(!matchValue){
                 rep[rep.length]= a[i]
           }

        
        
       
       
    }
    return seen
    
    
}

console.log(RepatedStr(str))