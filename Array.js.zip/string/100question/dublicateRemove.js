const data = [2, 3, 5, 2, 54, 2, 4, 3, 2, 23, 4];
const data1 = [
  "apple",
  "banana",
  "apple",
  "pimepapply",
  "orange",
  "pimepapply",
];

let dub = [];
for (let i = 0; i < data1.length - 1; i++) {
  if (!dub.includes(data1[i])) {
    dub.push(data1[i]);
  }
}
console.log(dub);



//  without inbuild method 
let str = "abbfghhvvavvvvvvvvvvvvvvv";

function RepatedStr(a) {
  let removedub = [];

  for (let i = 0; i <= a.length - 1; i++) {
    let checks = false;
    for (let j = 0; j <= removedub.length - 1; j++) {
      if (removedub[j] == a[i]) {
        checks = true;
        break;
        //   seen[seen.length]= a[i]
      }
    }
    if (!checks) {
      removedub[removedub.length] = a[i];
    }
  }
  return removedub;
}

console.log(RepatedStr(str));
